title: 在云服务器上搭建个人博客(solo)
date: '2019-05-06 22:55:39'
updated: '2019-05-06 23:25:00'
tags: [solo, docker]
permalink: /articles/2019/05/06/1557154539580.html
---
![](https://img.hacpai.com/bing/20180907.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

在云服务器上搭建博客(solo)
================

**今天来教大家用vps来搭建[solo](https://github.com/b3log/solo)；**
> solo是一款开源的，小而美的博客系统，专为程序员设计。

VPS配置
-----

我的vps是在[腾讯云](https://cloud.tencent.com/redirect.php?redirect=10064&cps_key=5656bc336722f918bdc107a00a8820aa)买的学生机

> 2G内存  镜像 CentOS 7.5 64位  CPU 1核  公网带宽 1Mbps

**这里推荐使用[阿里云学生机](https://promotion.aliyun.com/ntms/act/campus2018.html?spm=5176.10695662.1244717.1.17df4336WAg19X&userCode=380nubwa) 5m带宽，搭博客更爽**  ![null](https://img.hacpai.com/file/2019/05/aliyun-0de4ab47.png)

使用docker配置环境
------------

**直接用安装docker**

```
yum install docker -y #安装docker
```

因为我是用**solo**来搭博客，solo是用java来写的，所以我要配置java环境

`yum -y install java-1.8.0-openjdk.x86_64 #安装Java`

**docker 安装好后，用docker来下载mysql 8.0数据库,下载solo本体**

```
docker pull mysql:8.0 # 下载mysql 8.0  
docker pull b3log/solo # 下载solo
```

**运行mysql**

```
docker run --name mysql -p 3306:3306 -e MYSQL_ROOT_PASSWORD=123456 -d mysql8.0   
​  
docker ps # 查看启动是否成功，可以多试几次
```

**启动成功后，进入mysql中**

```
docker exec -it mysql bash # 进入docker容器  
​  
mysql -uroot -p123456 # 进入mysql  
​  
create database solo DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci; # 创建solo数据库设置它的编码为utf8mb4，排序规则为utf8mb4_general_ci  
​  
exit # 退出mysql  
exit # 退出docker容器  
​
```

**上面的操作成功后，启动solo**

```
docker run --detach --name solo --network=host \  
 --env RUNTIME_DB="MYSQL" \  
 --env JDBC_USERNAME="root" \  
 --env JDBC_PASSWORD="123456" \  
 --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \  
 --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC" \  
 b3log/solo --listen_port=80 --server_scheme=http --server_host=你的ip或者域名
```

> listen_port 这里填的是你的solo监听的端口，我这里直接就填的80，可以直接通过ip访问你的博客  server_host 这里是填你自己的ip或域名。
域名要注意，根据你的解析规则来填  如：`bjzt.com`这种格式不行的话，试试`www.bjzt.com`

**这时访问你的ip或者域名就可以进到solo了；**
![进入.png](https://user-images.githubusercontent.com/970828/56885783-df49a280-6a9f-11e9-8f52-bc37fcb03bc5.png)