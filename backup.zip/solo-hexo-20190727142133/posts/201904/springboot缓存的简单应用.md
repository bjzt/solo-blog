title: springboot 缓存的简单应用
date: '2019-04-25 14:39:22'
updated: '2019-05-05 23:29:23'
tags: [spring, springboot]
permalink: /articles/2019/04/25/1556174362083.html
---
![](https://img.hacpai.com/bing/20190109.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

今天用spring boot的缓存的时候，因为我是使用的注解开发，想在类中手动添加缓存

在网上查了下资料，也没找到怎么办，但看到了一个类 `CacheManager`

然后想将它注入到Class中，我就试了一下，成功实现我的需求

代码如下
```
    @Autowired
    CacheManager cacheManager;//直接注入缓存管理器
```

```
        //获取缓存
        Cache cache = cacheManager.getCache("cacheName");//缓存的value(名)
        if (ipCache.get("key")==null){//如果缓存为空
            //存入缓存
            ipCache.put("key",object);
        }
```