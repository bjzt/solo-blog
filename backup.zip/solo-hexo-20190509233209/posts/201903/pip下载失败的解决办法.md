title: pip下载失败的解决办法
date: '2019-03-19 10:35:05'
updated: '2019-03-20 22:57:13'
tags: [python]
permalink: /articles/2019/03/19/1552962905003.html
---
最近在新电脑装了python后，用pip安装模块的时候，经常下到一半报错；
我就上网查了下，原来是网络不好
解决办法是可以更换国内源

国内源：
---
清华：https://pypi.tuna.tsinghua.edu.cn/simple

阿里云：http://mirrors.aliyun.com/pypi/simple/

中国科技大学 https://pypi.mirrors.ustc.edu.cn/simple/

华中理工大学：http://pypi.hustunique.com/

山东理工大学：http://pypi.sdutlinux.org/ 

豆瓣：http://pypi.douban.com/simple/

临时使用：
-----

可以在使用pip的时候加参数-i https://pypi.tuna.tsinghua.edu.cn/simple  
  
例如：pip install -i https://pypi.tuna.tsinghua.edu.cn/simple pyspider，这样就会从清华这边的镜像去安装pyspider库。


永久修改，一劳永逸：
----------

Linux下，修改 ~/.pip/pip.conf (没有就创建一个文件夹及文件。文件夹要加“.”，表示是隐藏文件夹)

内容如下：

```
[global]
index-url = https://pypi.tuna.tsinghua.edu.cn/simple  
[install]
trusted-host=mirrors.aliyun.com
```

windows下，在user目录中创建一个pip目录,如C:\Users\xx\pip，新建文件pip.ini,内容如下：
```
[global]
index-url = https://pypi.tuna.tsinghua.edu.cn/simple  
[install]
trusted-host=mirrors.aliyun.com
```