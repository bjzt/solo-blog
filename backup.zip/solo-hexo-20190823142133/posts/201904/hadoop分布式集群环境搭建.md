title: hadoop分布式集群环境搭建
date: '2019-04-12 15:38:21'
updated: '2019-04-12 15:38:21'
tags: [hadoop]
permalink: /articles/2019/04/12/1555054701479.html
---
### 环境准备

#### 集群规划

*   主节点：hadoop100 从节点：hadoop101、hadoop102  
hadoop100 namenode、resourcemanager、secondarynamenode 
hadoop101 datanode、nodemanager  
hadoop102 datanode、nodemanager
    
*   修改hosts、hostname、免密码登录  基本的配置可以参考伪分布安装
    
*   **注意**：针对免密码登录功能需要配置主节点可以免密登录到从节点【还需要保证主节点能够免密码登录自己
    
*   **注意**：需要保证集群的各个节点时间同步 ntpdate -u ntp.sjtu.edu.cn
    
*   启动【只需要在主节点启动脚本即可】  在hadoop100上首先对hdfs进行格式化  在hadoop100上执行start-dfs.sh 启动namenode、datanode、secondarynamenode  在hadoop100上执行start-yarn.sh 启动resourcemanager、nodemanager
    
*   验证
    
    *   jps
        
    *   hdfs和yarn的webui界面【50070和8088端口】
        
### 更改配置文件
**hadoop-env.sh**

```
export JAVA_HOME={your JAVA_HOME}  
export HADOOP_LOG_DIR=/data/hadoop_repo/logs/hadoop
```

**yarn-env.sh**

```
export JAVA_HOME=/data/soft/jdk1.8  
export YARN_LOG_DIR=/data/hadoop_repo/logs/yarn
```

**core-site.xml**

```xml
<configuration>  
 <property>  
 <name>fs.defaultFS</name>  
 <value>hdfs://hadoop100:9000</value>  
 </property>  
 <property>  
 <name>hadoop.tmp.dir</name>  
 <value>/data/hadoop_repo</value>  
 </property>  
</configuration>
```

**hdfs-site.xml**

```
<!-- 集群中2个从节点，所以这个副本参数可以设置为2。如果从节点足够多的话，在工作中一般建议设置为3。 -->  
<configuration>  
   <property>  
 	<name>dfs.replication</name>  
	<value>1</value>  
   </property>  
</configuration>
```

**yarn-site.xml**

```
<configuration>  
 <property>  
 	<name>yarn.nodemanager.aux-services</name>  
	 <value>mapreduce_shuffle</value>  
 </property>  
     <property>  
	<name>yarn.resourcemanager.hostname</name>  
	<value>hadoop100</value>  
    </property>   
</configuration>
```

**mapred-site.xml**

```xml
 <!-- mv mapred-site.xml.template  mapred-site.xml  --> 
<configuration>  
    <property>  
 	<name>mapreduce.framework.name</name>  
	<value>yarn</value>  
    </property>  
</configuration>
```

**slaves**

```shell
hadoop101  
hadoop102
```