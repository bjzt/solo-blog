title: spring-data-rest,快速开发 restful api
date: '2019-07-02 16:00:11'
updated: '2019-07-02 16:00:52'
tags: [spring-data-rest]
permalink: /articles/2019/07/02/1562054411352.html
---
# spring data rest 是什么？

> Spring Data REST是基于Spring Data的repository之上，可以把 repository 自动输出为REST资源，目前支持Spring Data JPA、Spring Data MongoDB、Spring Data Neo4j、Spring Data GemFire、Spring Data Cassandra的 repository 自动转换成REST服务。注意是自动。简单点说，Spring Data REST把我们需要编写的大量REST模版接口做了自动化实现.

# 编写代码
### 依赖环境(maven)
`spring boot 2.1.5.RELEASE` `spring-data-rest` `spring-data-jpa`

#### pojo
```
@Entity
@Table(name = "tb_user")
public class User implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String username;
    private String password;
}
```
### repository(DAO)
```
//@RepositoryRestResource 就是使用了restful 风格来返回结果
@RepositoryRestResource(collectionResourceRel = "user", path = "user")
public interface UserDao extends JpaRepository<User,Integer> {
}
```
代码就编写完成了

### 结果
在浏览器里输入        `localhost:8080`
**返回结果**
```
{
  "_links" : {
    "user" : {
      "href" : "http://localhost:8080/user{?page,size,sort}",
      "templated" : true
    },
    "profile" : {
      "href" : "http://localhost:8080/profile"
    }
  }
}
```
在"_links"里有 api 的一些基本消息
**再输入** `localhost:8080/user`
返回结果
```
{
    "_embedded": {
        "user": []
    },
    "_links": {
        "self": {
            "href": "http://localhost:8080/user{?page,size,sort}",
            "templated": true
        },
        "profile": {
            "href": "http://localhost:8080/profile/user"
        }
    },
    "page": {
        "size": 20,
        "totalElements": 0,
        "totalPages": 0,
        "number": 0
    }
}
```
使用post方法发送json数据 `http://localhost:8080/user`
json数据为
```
{
	"username":"admin",
	"password":"123456"
}
```
结果
```
{
    "username": "admin",
    "password": "123456",
    "_links": {
        "self": {
            "href": "http://localhost:8080/user/1"
        },
        "user": {
            "href": "http://localhost:8080/user/1"
        }
    }
}
```
接下来就是普通的restful 的增删改查的功能了，我就不细说了，
上面其实都有一个问题，就是返回结果的id都没有显示，下面就来解决这个问题

## 解决spring-data-rest id不暴露的问题
加上这个配置类，就行了
```
@Configuration
public class SpringDataRestConfig {
    @Bean
    public RepositoryRestConfigurer repositoryRestConfigurer() {
        return new RepositoryRestConfigurer() {
            @Override
            public void configureRepositoryRestConfiguration( RepositoryRestConfiguration config) {
                config.exposeIdsFor(User.class);//这里填你自己的pojo
            }
        };
    }
}
```
### get访问 `localhost:8080/user`
```
{
    "_embedded": {
        "user": [
            {
                "id": 1,
                "username": "admin",
                "password": "123456",
                "_links": {
                    "self": {
                        "href": "http://localhost:8080/user/1"
                    },
                    "user": {
                        "href": "http://localhost:8080/user/1"
                    }
                }
            },
            {
                "id": 2,
                "username": "admin",
                "password": "123456",
                "_links": {
                    "self": {
                        "href": "http://localhost:8080/user/2"
                    },
                    "user": {
                        "href": "http://localhost:8080/user/2"
                    }
                }
            }
        ]
    },
    "_links": {
        "self": {
            "href": "http://localhost:8080/user{?page,size,sort}",
            "templated": true
        },
        "profile": {
            "href": "http://localhost:8080/profile/user"
        }
    },
    "page": {
        "size": 20,
        "totalElements": 2,
        "totalPages": 1,
        "number": 0
    }
}
```