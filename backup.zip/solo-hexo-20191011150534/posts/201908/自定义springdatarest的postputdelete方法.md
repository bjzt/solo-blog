title: 自定义 spring data rest 的post\put\delete 方法
date: '2019-08-11 00:01:10'
updated: '2019-08-11 00:24:29'
tags: [spring-data-rest, springboot, spring]
permalink: /articles/2019/08/11/1565452870855.html
---
之前写的springdatarest的简单使用，但是我们的实际项目中应该是会很复杂的增删改查，所以默认的rest的逻辑应该是无法满足我们的需求的。

### 方法
重写 这些方法很简单
spring data rest 已经提供了相应的事件

*   BeforeCreateEvent
*   AfterCreateEvent
*   BeforeSaveEvent
*   AfterSaveEvent
*   BeforeLinkSaveEvent
*   AfterLinkSaveEvent
*   BeforeDeleteEvent
*   AfterDeleteEvent

抽象类`AbstractRepositoryEventListener`已经对这些事件做了处理，
只要继承`AbstractRepositoryEventListener`，实现下面的方法就行了。
```
    protected void onBeforeCreate(T entity) {
    }

    protected void onAfterCreate(T entity) {
    }

    protected void onBeforeSave(T entity) {
    }

    protected void onAfterSave(T entity) {
    }

    protected void onBeforeLinkSave(T parent, Object linked) {
    }

    protected void onAfterLinkSave(T parent, Object linked) {
    }

    protected void onBeforeLinkDelete(T parent, Object linked) {
    }

    protected void onAfterLinkDelete(T parent, Object linked) {
    }

    protected void onBeforeDelete(T entity) {
    }

    protected void onAfterDelete(T entity) {
    }
```
### 实现
```
@Component
public class RestEventListener extends AbstractRepositoryEventListener<User> {

     /**
     * id生成器
     */
    @Autowired
    private IdWorker idWorker;

     /**
     * 在创建对象到数据库之前，先为id 赋值
     */    
    @Override
    public void onBeforeCreate(User entity) {
        user.setId(idworker.nextId())
    }
}
```
这是为单个pojo实现，想要统一做处理的话，可以创一个抽象类，所有要查数据库的类都来继承它，这里的泛型直接填它，统一对它做操作就好了
### 另一种方法
实际上还有另一种方法
新建一个处理器类，加上`@RepositoryEventHandler`注解
```
@RepositoryEventHandler    
public  class  PersonEventHandler  {  
	@HandleBeforeSave  
	public  void handlePersonSave(Person p)  {  
		// 对不同的类型进行处理
	}  
	@HandleBeforeSave  
	public  void handleProfileSave(Profile p)  {  
		// 对不同的类型进行处理
	}  
}
```
`@RepositoryEventHandler `也可以这样`@RepositoryEventHandler(Person.class)`来缩小处理的范围
然后将这个handler配置到spring容器
```
@Configuration  
public  class  RepositoryConfiguration  {  
	@Bean  PersonEventHandler personEventHandler()  {  
		return  new  PersonEventHandler();  
	}  
}
```
完成