title: Javalin 微服务框架的初步使用
date: '2019-05-29 14:03:45'
updated: '2019-05-29 15:04:36'
tags: [java, 微服务]
permalink: /articles/2019/05/29/1559109825698.html
---
![](https://img.hacpai.com/bing/20180206.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

> Javalin(https://github.com/tipsy/javalin/)是一款非常适合Kotlin和Java程序员的轻量级Web框架，它第一个版本是2017年6月份发布的，目前稳定版本为 `Javalin2.8.0`。Javalin主要有以下的特点：
轻量级：不用提前学习任何概念就可以开始使用
　　一致的API：所有的处理程序和映射器在Context (ctx)中都是无效的。
　　Kotlin和Java拥有几乎完全相同的API
　　是框架也是库：无需扩展任何功能
　　拥有完全可定制的嵌入式服务器(Jetty)
　　JSON对象映射
　　通过AccessManager 接口简单的按端点验证
　　简单的静态文件处理
　　生命周期事件
　　CookieStore——一种简单的用来序列化的方法和存储在cookie中的对象。
　　模板渲染
　　Markdown渲染

今天我就来试试
#### 引入maven依赖
```
<dependency>
    <groupId>io.javalin</groupId>
    <artifactId>javalin</artifactId>
    <version>2.8.0</version>
</dependency>
```
#### 写一下hello word
```
public class Application {
    public static void main(String[] args) {
        Javalin app = Javalin.create().start(7000);
        app.get("/", new Handler() {
            @Override
            public void handle(@NotNull Context context) throws Exception {
		context.result("Hello World")
            }
        });
}
```
#### 成功访问
![HUYX0DLK4HT8KG.png](https://img.hacpai.com/file/2019/05/HUYX0DLK4HT8KG-d4818b85.png)

它的api特别简单
你可以在`app`后点上`before`, `get`, `post`, `put`, `delete`, `after`
```
app.before("/some-path/*", ctx ->  {  
   // 在所有请求 "/some-path/*" 前运行 
}); 
app.before(ctx ->  {
  // 在所有请求前运行("/*", handler)  
});
```
## 再来使用restful 风格做个测试
#### 入口方法
```
public static void main(String[] args) {
        Javalin app = Javalin.create().start(7000);
        app.routes(() -> {
            path("users", () -> {
                get(UserController::getAllUsers);
                post(UserController::createUser);
                path(":id", () -> {
                    get(UserController::getUser);
                    patch(UserController::updateUser);
                    delete(UserController::deleteUser);
                });
            });
        });
    }
```
#### User 代码
```
public class User implements Serializable {
    private String name;
    private String sex;
    private Integer age;
    //getter、setter 省略
}
```
#### UserController代码
```
public class UserController {
    public static void getAllUsers(Context context) {
        List<User> users = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            User user = new User();
            user.setName("name"+i);
            user.setSex("男");
            user.setAge(10+i);
            users.add(user);
        }
        context.json(users);
    }

    public static void createUser(Context context) {
        User user = context.bodyAsClass(User.class);
        context.json(user);
    }

    public static void getUser(Context context) {
        //获取id
        String id = context.pathParam("id");
        User user = new User();
        user.setName("name");
        user.setSex("男");
        user.setAge(10);
        context.json(user);
    }

    public static void updateUser(Context context) {
        //获取id
        String id = context.pathParam("id");
        context.result(id+" 更新成功了");
    }

    public static void deleteUser(Context context) {
        //获取id
        String id = context.pathParam("id");
        context.result(id+" 删除成功了");
    }
}
```
### 结果
**get "/users"**
![PZUH6R7QH4DVT24.png](https://img.hacpai.com/file/2019/05/PZUH6R7QH4DVT24-ea73bf5a.png)
**post "/users"**
![CADWGMF0PTGCVXEVCW.png](https://img.hacpai.com/file/2019/05/CADWGMF0PTGCVXEVCW-a73a7b65.png)
**get "/users/:id"**
![FKAUQPK4MBK8PK96OOB1L.png](https://img.hacpai.com/file/2019/05/FKAUQPK4MBK8PK96OOB1L-d935c6db.png)
**patch "/users/:id"**
![3WM4HNF3AJBXX782N.png](https://img.hacpai.com/file/2019/05/3WM4HNF3AJBXX782N-c6a865d2.png)
**delete "/users/:id"**
![JSJ9ZW0PRQDZJ1Q06.png](https://img.hacpai.com/file/2019/05/JSJ9ZW0PRQDZJ1Q06-3eddd481.png)
### 文件上传
在`Javalin`中上传文件非常简单
```
app.post("/upload", ctx -> {
	ctx.uploadedFiles("files").forEach(file ->
	     FileUtil.streamToFile(file.getContent(), "upload/" + file.getName())
        );
        ctx.res.setCharacterEncoding("utf-8");
        ctx.result("文件上传成功");
});
```
这样就写好了
#### 现在测试一下
在启动类上加上`enableStaticFiles("/classpath-folder")`
```
Javalin app = Javalin
       .create()
       .enableStaticFiles("/classpath-folder")//开启静态资源
       .start(7000);
```
在根目录下建个`classpath-folder`文件夹
在`classpath-folder`文件夹下建个 `index.html`
```
<form method="post" action="/upload" enctype="multipart/form-data">
    <input type="file" name="files" multiple>
    <button>Submit</button>
</form>
```
#### 运行结果
![IMP2WYNYGTUOHTSJETH.png](https://img.hacpai.com/file/2019/05/IMP2WYNYGTUOHTSJETH-06cbdb42.png)
#### 文件上传成功
![0WXPPG503N9160.png](https://img.hacpai.com/file/2019/05/0WXPPG503N9160-dbded9aa.png)
#### 文件会默认上传到upload目录下
![3HYPS062HWON5L.png](https://img.hacpai.com/file/2019/05/3HYPS062HWON5L-01b25696.png)


### [官方文档](https://javalin.io/documentation)：https://javalin.io/documentation