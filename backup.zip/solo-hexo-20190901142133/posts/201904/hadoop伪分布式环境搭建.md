title: hadoop伪分布式环境搭建
date: '2019-04-12 15:13:32'
updated: '2019-04-12 15:17:01'
tags: [hadoop]
permalink: /articles/2019/04/12/1555053212527.html
---
![](https://img.hacpai.com/bing/20190329.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 环境准备
> 准备linux环境【java、ip、hostname、hosts、iptables、chkconfig、ssh、免密码登录】
依赖环境 jdk1.8
下载地址：
官网下载地址：https://archive.apache.org/dist/hadoop/common/hadoop-2.7.5/ 【版本最全，国内下载速度慢】
镜像站下载地址：https://mirrors.tuna.tsinghua.edu.cn/apache/hadoop 【只有最近的一些版本，国内下载速度快】
解压缩安装包hadoop-2.7.5.tar.gz
主要修改$HADOOP_HOME/etc/hadoop目录下的配置文件core-site.xml、hdfs-site.xml、yarn-site.xml、mapred-site.xml
还有hadoop-env.sh、yarn-env.sh、slaves文件中的内容也需要修改
启动
第一次启动之前需要先格式化
验证
jps验证
浏览器验证
hdfs web地址：http://hadoop100:50070
yarn web地址：http://hadoop100:8088

### 更改配置文件
**hadoop-env.sh**
```shell
export JAVA_HOME={your JAVA_HOME}
export HADOOP_LOG_DIR=/data/hadoop_repo/logs/hadoop
```
**yarn-env.sh**
```shell
export JAVA_HOME=/data/soft/jdk1.8
export YARN_LOG_DIR=/data/hadoop_repo/logs/yarn
```
**core-site.xml**
```
<configuration>
   <property>
 	<name>fs.defaultFS</name>
	 <value>hdfs://hadoop100:9000</value>
   </property>
   <property>
 	<name>hadoop.tmp.dir</name>
	 <value>/data/hadoop_repo</value>
   </property>
</configuration>
```
**hdfs-site.xml**
```
<configuration>
    <property>
 	<name>dfs.replication</name>
	 <value>1</value>
    </property>
</configuration>
```
**yarn-site.xml**
```
<configuration>
   <property>
 	<name>yarn.nodemanager.aux-services</name>
	<value>mapreduce_shuffle</value>
   </property>
</configuration>
```
**mapred-site.xml**
```
<configuration>
   <property>
 	<name>mapreduce.framework.name</name>
	<value>yarn</value>
   </property>
</configuration>
```
**slaves**
```
localhost
```
### 格式化hdfs
```
bin/hdfs namenode -format
# 格式化操作不能重复执行。
# 如果一定要重复格式化，带参数-force即可。
```
![图片3.png](https://img.hacpai.com/file/2019/04/图片3-92316222.png)

#### 详细启动脚本介绍
* 第一种：全部启动集群所有进程
启动：sbin/start-all.sh
停止：sbin/stop-all.sh
* 第二种：单独启动hdfs【web端口50070】和yarn【web端口8088】的相关进程
启动：sbin/start-hdfs.sh  sbin/start-yarn.sh
停止：sbin/stop-hdfs.sh  sbin/stop-yarn.sh
每次重新启动集群的时候使用
* 第三种：单独启动某一个进程
启动hdfs：sbin/hadoop-daemon.sh start (namenode | datanode)
停止hdfs：sbin/hadoop-daemon.sh stop (namenode | datanode)
启动yarn：sbin/yarn-daemon.sh start (resourcemanager | nodemanager)
停止yarn：sbin/yarn-daemon.sh stop(resourcemanager | nodemanager)
用于当某个进程启动失败或者异常down掉的时候，重启进程
####   验证集群是否启动成功
执行jps命令，能看到下面进程就说明启动成功
![图片4.png](https://img.hacpai.com/file/2019/04/图片4-85738006.png)

