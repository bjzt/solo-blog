title: web项目实现打印机功能
date: '2019-05-03 23:03:40'
updated: '2019-05-05 23:27:40'
tags: [web, 打印机]
permalink: /articles/2019/05/03/1556895820567.html
---
![](https://img.hacpai.com/bing/20190203.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

>之前有web项目要用到打印机功能，来打印小票；
我在网上搜了下就是简单的js代码来实现打印机；
但我的业务不能在页面再来设计打印的功能的配置；

所以我找了个第三方的浏览器控件——[Lodop](http://www.lodop.net/demo.html)
我就是使用的Lodop

### 首先来配置环境
先来下载Lodop的环境
[Lodop综合版(Lodop6.226+CLodop3.083)](http://www.lodop.net/download/Lodop6.226_Clodop3.083.zip)

在下载的压缩文件解压缩后的`CLodop_Setup_for_Win32NT.exe`安装，就可以使用了。
### 使用
在html导入,在head或body中加入
```
<script language="javascript" src="LodopFuncs.js"></script>
```
使用的话
```
var LODOP=getLodop();//直接这样就得到了打印控件对象
```
常用的方法
```
PRINT_INIT(strPrintTaskName)//打印初始化
SET_PRINT_PAGESIZE(intOrient,intPageWidth,intPageHeight,strPageName)//设定纸张大小
ADD_PRINT_HTM(intTop,intLeft,intWidth,intHeight,strHtml)//增加超文本项
ADD_PRINT_TEXT(intTop,intLeft,intWidth,intHeight,strContent)//增加纯文本项
ADD_PRINT_TABLE(intTop,intLeft,intWidth,intHeight,strHtml)//增加表格项
ADD_PRINT_SHAPE(intShapeType,intTop,intLeft,intWidth,intHeight,intLineStyle,intLineWidth,intColor)//画图形
SET_PRINT_STYLE(strStyleName, varStyleValue)//设置对象风格
PREVIEW()//打印预览
PRINT()//直接打印
PRINT_SETUP()//打印维护
PRINT_DESIGN()//打印设计
```
这里使用它的官方的样例
```
<script language="javascript" type="text/javascript">        
        var LODOP; //声明为全局变量       
	function myPrint() {		       
		CreatePrintPage();       
		LODOP.PRINT();		       
	}; 
	function CreatePrintPage() {       
		LODOP=getLodop();         
		LODOP.PRINT_INIT("打印控件功能演示_Lodop功能_名片");       
		LODOP.ADD_PRINT_RECT(10,55,360,220,0,1);       
		LODOP.SET_PRINT_STYLE("FontSize",11);       
		LODOP.ADD_PRINT_TEXT(20,180,100,25,"郭德强");       
		LODOP.SET_PRINT_STYLEA(2,"FontName","隶书");       
		LODOP.SET_PRINT_STYLEA(2,"FontSize",15);		       
		LODOP.ADD_PRINT_TEXT(53,187,75,20,"科学家");       
		LODOP.ADD_PRINT_TEXT(100,131,272,20,"地址：中国北京社会科学院附近东大街西胡同");       
		LODOP.ADD_PRINT_TEXT(138,132,166,20,"电话：010-88811888");	       
	};      
</script> 
```
预览效果：
![js.png](https://img.hacpai.com/file/2019/05/js-70329342.png)

### 更直观的方法
上面的方法其实还是有点抽象的
Lodop也提供了直接打印html的方法
```
//直接将idName的内容打印出来
var strHtml  = document.getElementById("idName").innerHTML
LODOP.ADD_PRINT_HTM(10,55,"100%","100%",strHtml);
```
### 控制纸张大小、打印方向、连续打印和位置基点
```
SET_PRINT_PAGESIZE(intOrient,intPageWidth,intPageHeight,strPageName);
```
```
intOrient //打印方向及纸张类型
intPageWidth // 纸张宽，单位为0.1mm 譬如该参数值为45，则表示4.5mm,计量精度是0.1mm。
intPageHeight // 固定纸张时该参数是纸张高；高度自适应时该参数是纸张底边的空白高，计量单位与纸张宽一样。
strPageName//纸张类型名， intPageWidth等于零时本参数才有效，具体名称参见操作系统打印服务属性中的格式定义。关键字“CreateCustomPage”会在系统内建立一个名称为“LodopCustomPage”自定义纸张类型。
```
更多详细内容，请看[官方文档](http://www.lodop.net/LodopDemo.html) 
http://www.lodop.net/LodopDemo.html